package com.abdou.boucetta.plateapp.domain.utils.background;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Worker {
    private static final String TAG = "Worker";
    private static final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());

    public static <T> CustomCompletableFuture<T> executeInBackground(Callable<T> callable) {
        return CustomCompletableFuture.supplyAsync(callable, executorService);
    }

    public static <T> CustomCompletableFuture<T> runOnUiThreadAndGet(Callable<T> callable) {
        return CustomCompletableFuture.supplySync(callable);
    }

    public static void runOnUiThread(Runnable runnable) {
        if (isMainThread(Looper.myLooper())){
            runnable.run();
        }{
            mainHandler.post(runnable);
        }
    }

    private static boolean isMainThread(Looper looper) {
        return looper == Looper.getMainLooper();
    }
}
