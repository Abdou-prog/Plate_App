package com.abdou.boucetta.plateapp.domain.base.di.modules;

import android.app.Application;

import com.abdou.boucetta.plateapp.data.local.pref.SharedPreferencesHelper;
import com.abdou.boucetta.plateapp.domain.base.di.factories.AuthViewModelFactory;
import com.google.firebase.auth.FirebaseAuth;

import java.util.concurrent.ExecutorService;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.components.SingletonComponent;

@Module
@InstallIn(SingletonComponent.class)
public class FactoryModule {
    private static final String TAG = "FactoryModule";

    @Provides
    @Singleton
    public AuthViewModelFactory provideViewModelFactory(Application application,
                                                        FirebaseAuth auth,
                                                        SharedPreferencesHelper sharedPreferencesHelper) {
        return new AuthViewModelFactory(application, auth, sharedPreferencesHelper);
    }
}
