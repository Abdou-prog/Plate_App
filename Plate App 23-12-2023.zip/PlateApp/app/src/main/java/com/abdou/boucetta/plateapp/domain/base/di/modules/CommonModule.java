package com.abdou.boucetta.plateapp.domain.base.di.modules;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.KeyPairGeneratorSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.room.Room;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;
import androidx.security.crypto.MasterKeys;

import com.abdou.boucetta.plateapp.R;
import com.abdou.boucetta.plateapp.data.local.database.AppDatabase;
import com.abdou.boucetta.plateapp.data.local.pref.SharedPreferencesHelper;
import com.abdou.boucetta.plateapp.data.remote.firestore.FirebaseFirestoreHelper;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.IOException;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.KeyPairGenerator;

import javax.inject.Singleton;
import javax.security.auth.x500.X500Principal;

import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.android.qualifiers.ApplicationContext;
import dagger.hilt.components.SingletonComponent;

@Module
@InstallIn(SingletonComponent.class)
public class CommonModule {
    private static final String TAG = "CommonModule";
    private static final String DATABASE_NAME = "plateDB";

    @Singleton
    @Provides
    public static SharedPreferencesHelper providesSharedPreferences(@ApplicationContext Context context) {
        try {
            MasterKey masterKey;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                        MasterKey.DEFAULT_MASTER_KEY_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(MasterKey.DEFAULT_AES_GCM_MASTER_KEY_SIZE)
                        .build();

                masterKey = new MasterKey.Builder(context)
                        .setKeyGenParameterSpec(spec)
                        .build();
            } else {
                masterKey = new MasterKey.Builder(context)
                        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                        .build();
            }
            SharedPreferences sharedPreferences = EncryptedSharedPreferences.create(
                    context,
                    context.getString(R.string.preference_file_key),
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
            return new SharedPreferencesHelper(sharedPreferences);

        } catch (Throwable e) {
            String message = "providesSharedPreferences: Error creating EncryptedSharedPreferences";
            Log.e(TAG, message, e);
            FirebaseCrashlytics.getInstance().log(message);
            FirebaseCrashlytics.getInstance().recordException(e);
            // Provide a default SharedPreferences instance
            return new SharedPreferencesHelper(context.getSharedPreferences(
                    context.getString(R.string.preference_file_key),
                    Context.MODE_PRIVATE));
        }
    }

    @Provides
    @Singleton
    public FirebaseAuth provideFirebaseAuth() {
        return FirebaseAuth.getInstance();
    }

    @Provides
    @Singleton
    public FirebaseFirestore provideFirebaseFirestore() {
        return FirebaseFirestore.getInstance();
    }

    @Provides
    @Singleton
    public FirebaseFirestoreHelper provideFirebaseFirestoreHelper(FirebaseFirestore firebaseFirestore) {
        return new FirebaseFirestoreHelper(firebaseFirestore);
    }


    @Provides
    @Singleton
    public static AppDatabase providesAppDatabase(@ApplicationContext Context context) {
        return Room.databaseBuilder(context, AppDatabase.class, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .build();
    }
}
