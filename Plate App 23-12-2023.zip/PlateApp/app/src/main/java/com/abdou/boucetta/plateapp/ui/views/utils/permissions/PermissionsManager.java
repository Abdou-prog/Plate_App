package com.abdou.boucetta.plateapp.ui.views.utils.permissions;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.os.Build;
import android.util.Log;

public class PermissionsManager {
    private static final String TAG = "PermissionsManager";

    private static final int PERMISSIONS_CODE = 100;
    private final Activity activity;
    private final PermissionCallback permissionCallback;
    private final String[] cameraPermissions;
    private final String[] storagePermissions;

    public interface PermissionCallback {
        void onPermissionsGranted();

        void onPermissionsDenied();
    }

    public PermissionsManager(Activity activity, @Nullable PermissionCallback permissionCallback) {
        this.activity = activity;
        this.permissionCallback = permissionCallback;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            cameraPermissions = new String[]{
                    Manifest.permission.CAMERA,
            };
            storagePermissions = new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
            };
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            cameraPermissions = new String[]{
                    Manifest.permission.CAMERA,
            };
            storagePermissions = new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
            };
        } else {
            cameraPermissions = new String[]{
                    Manifest.permission.CAMERA,
            };
            storagePermissions = new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
            };
        }
    }

    public void requestAllPermissions() {
        String[] allPermissions = concatenateArrays(cameraPermissions, storagePermissions);
        if (arePermissionsGranted(allPermissions)) {
            if (permissionCallback != null) {
                permissionCallback.onPermissionsGranted();
            }
        } else {
            ActivityCompat.requestPermissions(
                    activity,
                    allPermissions,
                    PERMISSIONS_CODE
            );
        }
    }

    public void requestStoragePermissions() {

        if (arePermissionsGranted(storagePermissions)) {
            if (permissionCallback != null) {
                permissionCallback.onPermissionsGranted();
            }
        } else {
            ActivityCompat.requestPermissions(
                    activity,
                    storagePermissions,
                    PERMISSIONS_CODE
            );
        }
    }

    public boolean arePermissionsGranted(String[] permissions) {
        for (String permission : permissions) {
            if (!isPermissionGranted(permission)){
                return false;
            }
        }
        return true;
    }

    public boolean isPermissionGranted(String permission) {
        return ContextCompat.checkSelfPermission(
                activity,
                permission
        ) == PackageManager.PERMISSION_GRANTED;
    }

    public boolean isCameraPermissionGranted() {
        return isPermissionGranted(Manifest.permission.CAMERA);
    }
    public boolean isStoragePermissionGranted() {
        return arePermissionsGranted(storagePermissions);
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSIONS_CODE) {
            // Check each permission and its result
            for (int i = 0; i < permissions.length; i++) {
                String permission = permissions[i];
                int grantResult = grantResults[i];

                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted
                    Log.e(TAG, "onRequestPermissionsResult: granted : " + permission );
                } else {
                    // Permission denied
                    Log.e(TAG, "onRequestPermissionsResult: denied : " + permission );
                }
            }

            // Check if all permissions are granted
            boolean allPermissionsGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (allPermissionsGranted) {
                // All permissions granted
                if (permissionCallback != null) {
                    permissionCallback.onPermissionsGranted();
                }
            } else {
                // Some or all permissions denied
                if (permissionCallback != null) {
                    permissionCallback.onPermissionsDenied();
                }
            }
        }
    }

    private static String[] concatenateArrays(String[] array1, String[] array2) {
        int length1 = array1.length;
        int length2 = array2.length;
        String[] result = new String[length1 + length2];

        System.arraycopy(array1, 0, result, 0, length1);
        System.arraycopy(array2, 0, result, length1, length2);

        return result;
    }
}