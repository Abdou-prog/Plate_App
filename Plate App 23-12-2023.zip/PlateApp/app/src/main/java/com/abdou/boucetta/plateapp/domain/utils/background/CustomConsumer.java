package com.abdou.boucetta.plateapp.domain.utils.background;

public interface CustomConsumer<T> {
    void accept(T t);
}
