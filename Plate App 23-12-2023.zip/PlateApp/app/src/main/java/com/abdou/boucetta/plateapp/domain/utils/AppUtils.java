package com.abdou.boucetta.plateapp.domain.utils;


import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AppUtils {
    public static final String TAG = "AppUtils";

    public static void initLogSetup() {
        Log.d(TAG, "initLogSetup: executed");

        if ( isExternalStorageWritable() ) {

            Date c = Calendar.getInstance().getTime();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = simpleDateFormat.format(c);

            File downloadsDirectory =
                    new File( Environment.getExternalStorageDirectory()
                            +"/" + Environment.DIRECTORY_DOWNLOADS +"/" );
            File logDirectory = new File( downloadsDirectory + "/plate_app_logs" );
            File logFile = new File( logDirectory, "plate_app_logcat_"
                    + formattedDate + ".txt" );

            // create app folder
            if ( !downloadsDirectory.exists() ) {
                downloadsDirectory.mkdir();
            }

            // create log folder
            if ( !logDirectory.exists() ) {
                logDirectory.mkdir();
            }

            // clear the previous logcat and then write the new one to the file
            try {
//                Runtime.getRuntime().exec("logcat -c");
                Runtime.getRuntime().exec("logcat -f " + logFile);
            } catch ( IOException e ) {
                Log.e(TAG, "initLogSetup: ", e);
            }

        } else if ( isExternalStorageReadable() ) {
            // only readable
            Log.e(TAG, "initLogSetup: readonly storage");
        } else {
            // not accessible
            Log.e(TAG, "initLogSetup: unaccessible storage");
        }
    }

    /* Checks if external storage is available for read and write */
    public static boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    /* Checks if external storage is available to at least read */
    public static boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state);
    }

}
