package com.abdou.boucetta.plateapp.ui.views.dialogs;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.abdou.boucetta.plateapp.R;
import com.abdou.boucetta.plateapp.databinding.DialogFailureBinding;
import com.bumptech.glide.Glide;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class FailureDialog extends AppCompatDialogFragment {
    public static final String TAG = "FailureDialog";
    private final FailureDialog.FailureDialogListener failureDialogListener;
    private final String title;
    private final String description;

    public FailureDialog(@Nullable String title,
                         @Nullable String description,
                         @Nullable FailureDialog.FailureDialogListener failureDialogListener) {
        this.title = title;
        this.description = description;
        this.failureDialogListener = failureDialogListener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireActivity());

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        DialogFailureBinding binding =
                DialogFailureBinding.inflate(inflater);

        builder.setView(binding.getRoot());

        Glide.with(binding.dialogFailureImg.getContext())
                .load(R.drawable.cloud_off_ic)
                .into(binding.dialogFailureImg);

        binding.dialogFailureCloseBtn.setOnClickListener(view -> {
            if (failureDialogListener != null) {
                failureDialogListener.onCloseBtnClick();
            }
            dismiss();
        });

        if (title != null){
            binding.dialogFailureTitle.setText(title);
        }

        if (description != null){
            binding.dialogFailureDescription.setText(description);
        }


        return builder.create();
    }

    public interface FailureDialogListener {
        void onCloseBtnClick();
    }
}
