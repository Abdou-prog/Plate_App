package com.abdou.boucetta.plateapp.ui.views.dialogs;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.abdou.boucetta.plateapp.R;
import com.abdou.boucetta.plateapp.databinding.DialogSuccessBinding;
import com.bumptech.glide.Glide;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class SuccessDialog extends AppCompatDialogFragment {
    public static final String TAG = "SuccessDialog";
    private final SuccessDialog.SuccessDialogListener successDialogListener;

    public SuccessDialog(@Nullable SuccessDialog.SuccessDialogListener successDialogListener) {
        this.successDialogListener = successDialogListener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireActivity());

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        DialogSuccessBinding binding =
                DialogSuccessBinding.inflate(inflater);

        builder.setView(binding.getRoot());

        Glide.with(binding.dialogSuccessImg.getContext())
                .load(R.drawable.check_ic)
                .into(binding.dialogSuccessImg);

        binding.dialogSuccessCloseBtn.setOnClickListener(view -> {
            if (successDialogListener != null) {
                successDialogListener.onCloseBtnClick();
            }
            dismiss();
        });


        return builder.create();
    }

    public interface SuccessDialogListener {
        void onCloseBtnClick();
    }
}
