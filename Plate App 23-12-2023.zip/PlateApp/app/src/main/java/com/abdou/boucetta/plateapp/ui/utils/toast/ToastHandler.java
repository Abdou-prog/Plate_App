package com.abdou.boucetta.plateapp.ui.utils.toast;

import android.content.Context;
import android.widget.Toast;

import com.abdou.boucetta.plateapp.domain.base.BaseApplication;

import java.lang.ref.WeakReference;

public class ToastHandler {
    private static final String TAG = "ToastHandler";

    private static WeakReference<Toast> toastRef;

    public static void showToast(String message, int duration) {
        cancelCurrentToast();
        Toast toast = Toast.makeText(BaseApplication.appContext, message, duration);
        toast.show();
        toastRef = new WeakReference<>(toast);
    }

    private static void cancelCurrentToast() {
        if (toastRef != null){
            Toast toast = toastRef.get();
            if (toast != null) {
                toast.cancel();
            }
        }
    }

    public static void showToastShort(String message) {
        showToast(message, Toast.LENGTH_SHORT);
    }

    public static void showToastLong(String message) {
        showToast(message, Toast.LENGTH_LONG);
    }

}
