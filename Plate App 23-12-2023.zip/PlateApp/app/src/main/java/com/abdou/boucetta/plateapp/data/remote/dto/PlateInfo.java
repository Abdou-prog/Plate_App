package com.abdou.boucetta.plateapp.data.remote.dto;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.ServerTimestamp;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlateInfo {
    public static String TYPE_SAFE = "Safe";
    public static String TYPE_DANGEROUS = "Dangerous";

    @DocumentId
    private String id;
    private String reference;
    private String type;
    @ServerTimestamp
    private Date lastModifiedDate;

}
