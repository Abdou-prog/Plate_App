package com.abdou.boucetta.plateapp.ui.views.custom;

public enum CustomRecyclerViewStates {
    LOADING,
    EMPTY,
    SHOW_DATA,
    ERROR
}