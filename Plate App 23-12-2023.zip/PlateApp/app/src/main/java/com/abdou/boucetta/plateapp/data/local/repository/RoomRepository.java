package com.abdou.boucetta.plateapp.data.local.repository;

import androidx.lifecycle.LiveData;

import com.abdou.boucetta.plateapp.data.local.dao.PlateDetectionResultDao;
import com.abdou.boucetta.plateapp.data.local.models.entities.PlateDetectionResult;

import java.util.List;

import javax.inject.Inject;

public class RoomRepository {
    private static final String TAG = "RoomRepository";

    private final PlateDetectionResultDao plateDetectionResultDao;
    @Inject
    public RoomRepository(PlateDetectionResultDao plateDetectionResultDao) {
        this.plateDetectionResultDao = plateDetectionResultDao;
    }

    /*******************************************************************************
     * PlateDetectionResult
     */
    public void insertPlateDetectionResult(PlateDetectionResult plateDetectionResult) {
        this.plateDetectionResultDao.insertPlateDetectionResult(plateDetectionResult);
    }

    public LiveData<List<PlateDetectionResult>> getAllPlateDetectionResults() {
        return this.plateDetectionResultDao.getAllPlateDetectionResults();
    }

    public void deletePlateDetectionResult(PlateDetectionResult plateDetectionResult) {
        this.plateDetectionResultDao.deletePlateDetectionResult(plateDetectionResult);
    }

    public void deletePlateDetectionResultList(List<PlateDetectionResult> plateDetectionResultList) {
        this.plateDetectionResultDao.deletePlateDetectionResultList(plateDetectionResultList);
    }

    public void deleteAllPlateDetectionResult() {
        this.plateDetectionResultDao.deleteAllPlateDetectionResult();
    }

}
