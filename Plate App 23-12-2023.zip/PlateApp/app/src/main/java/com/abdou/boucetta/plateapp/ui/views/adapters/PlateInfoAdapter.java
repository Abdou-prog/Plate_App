package com.abdou.boucetta.plateapp.ui.views.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.abdou.boucetta.plateapp.data.remote.dto.PlateInfo;
import com.abdou.boucetta.plateapp.databinding.ListItemHomePlateBinding;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class PlateInfoAdapter extends FirestoreRecyclerAdapter<PlateInfo,
        PlateInfoAdapter.PlateInfoViewHolder> {
    private static final String TAG = "PlateInfoAdapter";
//    private List<PlateInfo> dataList;
    private List<PlateInfo> dataListToRemove = new ArrayList<>();
    private final PlateInfoListener plateInfoListener;
    private boolean selectionMode = false;

    public PlateInfoAdapter(@NonNull FirestoreRecyclerOptions<PlateInfo> options,
                            PlateInfoListener plateInfoListener) {
        super(options);
        this.plateInfoListener = new PlateInfoListener() {
            @Override
            public void onItemClick(PlateInfo plateInfo) {
                if (selectionMode) {
                    if (dataListToRemove.contains(plateInfo)) {
                        dataListToRemove.remove(plateInfo);
                        plateInfoListener.onAllSelected(false);
                    } else {
                        if (dataListToRemove.size() == (getSnapshots().size() - 1)) {
                            toggleSelectAll();
                        } else {
                            dataListToRemove.add(plateInfo);
                            plateInfoListener.onAllSelected(false);
                        }
                    }
                    notifyDataSetChanged();
                } else {
                    plateInfoListener.onItemClick(plateInfo);
                }
            }

            @Override
            public void onItemLongClick(PlateInfo plateInfo) {
                if (!selectionMode) {
                    selectionMode = true;
                    dataListToRemove.add(plateInfo);
                    notifyDataSetChanged();
                    plateInfoListener.onItemLongClick(plateInfo);
                }
            }

            @Override
            public void onAllSelected(boolean isAllSelected) {
                plateInfoListener.onAllSelected(isAllSelected);
            }

            @Override
            public void onDeleteSelectedEvent(List<PlateInfo> plateInfos) {
                ArrayList<PlateInfo> clonedList = new ArrayList<>(plateInfos);
                if (selectionMode) {
                    dataListToRemove.clear();
                    notifyDataSetChanged();
                    selectionMode = false;
                }
                plateInfoListener.onDeleteSelectedEvent(clonedList);
            }

            @Override
            public void onResetSelection() {
                if (selectionMode) {
                    dataListToRemove.clear();
                    notifyDataSetChanged();
                    selectionMode = false;
                }
                plateInfoListener.onResetSelection();
            }
        };
    }

    @NonNull
    @Override
    public PlateInfoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ListItemHomePlateBinding binding =
                ListItemHomePlateBinding.inflate(LayoutInflater.from(parent.getContext()), parent
                        , false);
        return new PlateInfoViewHolder(binding, plateInfoListener);
    }

    @Override
    protected void onBindViewHolder(@NonNull PlateInfoViewHolder holder, int position,
                                    @NonNull PlateInfo currentItem) {
        holder.init(currentItem, selectionMode, dataListToRemove.contains(currentItem));
    }

    public void toggleSelectAll() {
        if (selectionMode) {
            if (new HashSet<>(dataListToRemove).containsAll(getSnapshots())) {
                dataListToRemove.clear();
                plateInfoListener.onAllSelected(false);
            } else {
                dataListToRemove.clear();
                dataListToRemove.addAll(getSnapshots());
                plateInfoListener.onAllSelected(true);
            }
            notifyDataSetChanged();
        }
    }

    public void deleteSelected() {
        plateInfoListener.onDeleteSelectedEvent(dataListToRemove);
    }

    public void resetSelection() {
        plateInfoListener.onResetSelection();
    }

    public static class PlateInfoViewHolder extends RecyclerView.ViewHolder {
        public ListItemHomePlateBinding binding;
        public PlateInfoListener plateInfoListener;

        public PlateInfoViewHolder(ListItemHomePlateBinding binding,
                                   PlateInfoListener plateInfoListener) {
            super(binding.getRoot());
            this.binding = binding;
            this.plateInfoListener = plateInfoListener;
        }

        public void init(PlateInfo currentItem, boolean selectionMode,
                         boolean isSelected) {
            binding.listItemHomePlateReferenceMTV.setText(currentItem.getReference());
            binding.listItemHomePlateTypeMTV.setText(currentItem.getType());
            binding.getRoot().setOnClickListener(view -> plateInfoListener.onItemClick(currentItem));
            binding.getRoot().setOnLongClickListener(view -> {
                plateInfoListener.onItemLongClick(currentItem);
                return true;
            });
            if (selectionMode) {
                binding.listItemHomePlateSelectedCB.setVisibility(View.VISIBLE);
                binding.listItemHomePlateSelectedCB.setChecked(isSelected);
            } else {
                binding.listItemHomePlateSelectedCB.setVisibility(View.GONE);
            }
        }
    }

    public interface PlateInfoListener {
        void onItemClick(PlateInfo plateInfo);

        void onItemLongClick(PlateInfo plateInfo);

        void onAllSelected(boolean isAllSelected);

        void onDeleteSelectedEvent(List<PlateInfo> plateInfos);

        void onResetSelection();
    }

}

