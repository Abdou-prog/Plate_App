package com.abdou.boucetta.plateapp.domain.viewmodels;

import android.util.Log;

import androidx.lifecycle.ViewModel;

import com.abdou.boucetta.plateapp.data.local.pref.SharedPreferencesHelper;
import com.abdou.boucetta.plateapp.domain.utils.background.Worker;
import com.abdou.boucetta.plateapp.domain.utils.background.CustomCompletableFuture;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class LoginViewModel extends ViewModel {
    private static final String TAG = "LoginViewModel";

    /***********************************************************************************************
     * *********************************** Declarations
     */

    private final SharedPreferencesHelper sharedPreferencesHelper;

    /***********************************************************************************************
     * *********************************** Constructor
     */
    @Inject
    public LoginViewModel(
            SharedPreferencesHelper sharedPreferencesHelper
    ) {
        this.sharedPreferencesHelper = sharedPreferencesHelper;
    }



    /***********************************************************************************************
     * *********************************** Methods
     */


    /***********************************************************************************************
     * *********************************** Data
     */

}
