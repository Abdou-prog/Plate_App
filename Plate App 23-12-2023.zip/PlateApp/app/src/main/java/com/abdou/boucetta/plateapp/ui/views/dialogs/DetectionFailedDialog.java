package com.abdou.boucetta.plateapp.ui.views.dialogs;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.abdou.boucetta.plateapp.R;
import com.abdou.boucetta.plateapp.databinding.DialogFailureBinding;
import com.bumptech.glide.Glide;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class DetectionFailedDialog extends AppCompatDialogFragment {
    public static final String TAG = "DetectionFailedDialog";
    private final DetectionFailedDialog.DetectionFailedDialogListener detectionResultDialogListener;
    private final String recognizedText;

    public DetectionFailedDialog(String recognizedText, @Nullable DetectionFailedDialogListener detectionResultDialogListener) {
        this.recognizedText = recognizedText;
        this.detectionResultDialogListener = detectionResultDialogListener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireActivity());

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        DialogFailureBinding binding =
                DialogFailureBinding.inflate(inflater);

        builder.setView(binding.getRoot());

        Glide.with(binding.dialogFailureImg.getContext())
                .load(R.drawable.cloud_off_ic)
                .into(binding.dialogFailureImg);

        binding.dialogFailureCloseBtn.setOnClickListener(view -> {
            if (detectionResultDialogListener != null) {
                detectionResultDialogListener.onCloseBtnClick();
            }
            dismiss();
        });

        binding.dialogFailureTitle.setText(getString(R.string.detection_failed_title));
        binding.dialogFailureDescription.setText(getString(R.string.detection_failed_description));
        String formattedString = String.format(getResources().getString(R.string.detected_text_description), recognizedText);
        binding.dialogFailureDetectedTextTIET.setText(formattedString);


        return builder.create();
    }

    public interface DetectionFailedDialogListener {
        void onCloseBtnClick();
    }
}
