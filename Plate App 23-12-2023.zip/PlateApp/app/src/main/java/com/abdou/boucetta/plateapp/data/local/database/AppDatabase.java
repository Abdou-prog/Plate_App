package com.abdou.boucetta.plateapp.data.local.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.abdou.boucetta.plateapp.data.local.converters.RoomConverters;
import com.abdou.boucetta.plateapp.data.local.dao.PlateDetectionResultDao;
import com.abdou.boucetta.plateapp.data.local.models.entities.PlateDetectionResult;


@Database(entities = {PlateDetectionResult.class}, version = 2, exportSchema = false)
@TypeConverters({RoomConverters.class})
public abstract class AppDatabase extends RoomDatabase {

    public abstract PlateDetectionResultDao plateDetectionResultDao();

}