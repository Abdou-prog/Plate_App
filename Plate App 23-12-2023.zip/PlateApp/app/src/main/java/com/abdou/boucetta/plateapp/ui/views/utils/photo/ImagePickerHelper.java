package com.abdou.boucetta.plateapp.ui.views.utils.photo;


import android.net.Uri;
import android.util.Log;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;

public class ImagePickerHelper {

    private static final String TAG = "PhotoPicker";

    private final ActivityResultLauncher<PickVisualMediaRequest> pickMedia;
    private final OnImagePickedListener onImagePickedListener;

    public ImagePickerHelper(ComponentActivity activity,
                             OnImagePickedListener onImagePickedListener) {
        this.onImagePickedListener = onImagePickedListener;
        pickMedia = createPickMediaLauncher(activity);
    }

    public ImagePickerHelper(Fragment fragment, OnImagePickedListener onImagePickedListener) {
        this.onImagePickedListener = onImagePickedListener;
        pickMedia = createPickMediaLauncher(fragment);
    }

    private ActivityResultLauncher<PickVisualMediaRequest> createPickMediaLauncher(ComponentActivity activity) {
        return activity.registerForActivityResult(
                new ActivityResultContracts.PickVisualMedia(),
                onImagePickedListener::onImagePicked
        );
    }

    private ActivityResultLauncher<PickVisualMediaRequest> createPickMediaLauncher(Fragment fragment) {
        return fragment.registerForActivityResult(
                new ActivityResultContracts.PickVisualMedia(),
                onImagePickedListener::onImagePicked
        );
    }


    public void pickImageGallery() {
        Log.d(TAG, "pickedImageGallery");
        pickMedia.launch(new PickVisualMediaRequest.Builder()
                .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                .build());
    }

    public interface OnImagePickedListener {
        void onImagePicked(android.net.Uri imageUri);
    }
}