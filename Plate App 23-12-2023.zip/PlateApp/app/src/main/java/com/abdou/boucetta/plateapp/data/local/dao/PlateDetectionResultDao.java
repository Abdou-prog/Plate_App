package com.abdou.boucetta.plateapp.data.local.dao;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.abdou.boucetta.plateapp.data.local.models.entities.PlateDetectionResult;

import java.util.List;

@Dao
public interface PlateDetectionResultDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertPlateDetectionResult(PlateDetectionResult plateDetectionResult);

    @Query("SELECT * FROM PlateDetectionResult")
    LiveData<List<PlateDetectionResult>> getAllPlateDetectionResults();

    @Delete
    void deletePlateDetectionResult(PlateDetectionResult plateDetectionResult);
    @Delete
    void deletePlateDetectionResultList(List<PlateDetectionResult> plateDetectionResultList);
    @Query("DELETE FROM PlateDetectionResult")
    void deleteAllPlateDetectionResult();

}