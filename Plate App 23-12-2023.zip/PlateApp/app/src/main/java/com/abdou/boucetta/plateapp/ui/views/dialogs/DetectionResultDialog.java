package com.abdou.boucetta.plateapp.ui.views.dialogs;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.abdou.boucetta.plateapp.data.local.models.entities.PlateDetectionResult;
import com.abdou.boucetta.plateapp.databinding.DialogDetectionResultBinding;
import com.bumptech.glide.Glide;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class DetectionResultDialog extends AppCompatDialogFragment {
    public static final String TAG = "DetectionResultDialog";
    private final DetectionResultDialogListener detectionResultDialogListener;
    private final PlateDetectionResult plateDetectionResult;

    public DetectionResultDialog(@NonNull PlateDetectionResult plateDetectionResult,
                                 @Nullable DetectionResultDialogListener detectionResultDialogListener) {
        this.plateDetectionResult = plateDetectionResult;
        this.detectionResultDialogListener = detectionResultDialogListener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireActivity());

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        DialogDetectionResultBinding binding =
                DialogDetectionResultBinding.inflate(inflater);

        builder.setView(binding.getRoot());

        Glide.with(binding.dialogDetectionResultPhoto.getContext())
                .load(plateDetectionResult.getImageUri())
                .into(binding.dialogDetectionResultPhoto);

        binding.dialogDetectionResultCloseBtn.setOnClickListener(view -> {
            if (detectionResultDialogListener != null) {
                detectionResultDialogListener.onCloseBtnClick();
            }
            dismiss();
        });

        binding.dialogDetectionResultReferenceTIET.setText(plateDetectionResult.getReference());
        binding.dialogDetectionResultTypeTIET.setText(plateDetectionResult.getType());


        return builder.create();
    }

    public interface DetectionResultDialogListener {
        void onCloseBtnClick();
    }
}
