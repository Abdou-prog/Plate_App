package com.abdou.boucetta.plateapp.domain.viewmodels;

import androidx.lifecycle.ViewModel;

import com.abdou.boucetta.plateapp.data.remote.dto.PlateInfo;
import com.abdou.boucetta.plateapp.data.local.pref.SharedPreferencesHelper;
import com.abdou.boucetta.plateapp.data.local.repository.RoomRepository;
import com.abdou.boucetta.plateapp.data.remote.firestore.FirebaseFirestoreHelper;
import com.abdou.boucetta.plateapp.domain.utils.background.Worker;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;

import java.util.List;
import java.util.concurrent.Callable;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class AdminViewModel extends ViewModel {
    private static final String TAG = "LoginViewModel";

    /***********************************************************************************************
     * *********************************** Declarations
     */

    private final SharedPreferencesHelper sharedPreferencesHelper;
    private final FirebaseFirestoreHelper firebaseFirestoreHelper;
    private final RoomRepository roomRepository;
    private final FirebaseAuth auth;

    /***********************************************************************************************
     * *********************************** Constructor
     */
    @Inject
    public AdminViewModel(
            SharedPreferencesHelper sharedPreferencesHelper,
            FirebaseFirestoreHelper firebaseFirestoreHelper,
            RoomRepository roomRepository,
            FirebaseAuth auth
    ) {
        this.sharedPreferencesHelper = sharedPreferencesHelper;
        this.firebaseFirestoreHelper = firebaseFirestoreHelper;
        this.roomRepository = roomRepository;
        this.auth = auth;
    }


    /***********************************************************************************************
     * *********************************** Methods
     */

    public boolean isLoggedIn() {
        return auth.getCurrentUser() != null;
    }

    /***********************************************************************************************
     * *********************************** Data
     */


    public void addPlateInfo(PlateInfo plateInfo){
        Worker.executeInBackground((Callable<PlateInfo>) () -> {
            firebaseFirestoreHelper.addPlateInfo(plateInfo);
            return null;
        });
    }

    public void editPlateInfo(PlateInfo plateInfo){
        Worker.executeInBackground((Callable<PlateInfo>) () -> {
            firebaseFirestoreHelper.editPlateInfo(plateInfo);
            return null;
        });
    }

    public void deletePlateInfos(List<PlateInfo> plateInfos) {
        Worker.executeInBackground((Callable<PlateInfo>) () -> {
            for (PlateInfo plateInfo : plateInfos) {
                firebaseFirestoreHelper.deletePlateInfo(plateInfo.getId());
            }
            return null;
        });
    }

    public FirestoreRecyclerOptions<PlateInfo> getAllPlateInfosQueryOptions() {
        return firebaseFirestoreHelper.getAllPlateInfosQueryOptions();
    }
}
