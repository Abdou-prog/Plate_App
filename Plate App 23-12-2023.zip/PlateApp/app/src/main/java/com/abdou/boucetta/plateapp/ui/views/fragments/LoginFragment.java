package com.abdou.boucetta.plateapp.ui.views.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.abdou.boucetta.plateapp.databinding.FragmentLoginBinding;
import com.abdou.boucetta.plateapp.domain.base.di.factories.AuthViewModelFactory;
import com.abdou.boucetta.plateapp.domain.utils.background.Worker;
import com.abdou.boucetta.plateapp.domain.viewmodels.AuthViewModel;
import com.abdou.boucetta.plateapp.domain.viewmodels.LoginViewModel;
import com.abdou.boucetta.plateapp.ui.utils.toast.ToastHandler;
import com.abdou.boucetta.plateapp.ui.views.MainActivity;
import com.abdou.boucetta.plateapp.ui.views.dialogs.ProgressDialog;
import com.abdou.boucetta.plateapp.ui.views.navigation.MainNavigationHandler;
import com.abdou.boucetta.plateapp.ui.views.utils.ValidationUtils;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import java.util.ArrayList;
import java.util.concurrent.Callable;

import javax.inject.Inject;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class LoginFragment extends Fragment {
    private static final String TAG = "LoginFragment";

    /***********************************************************************************************
     * *********************************** Declarations
     */

    private FragmentLoginBinding binding;
    private LoginViewModel loginViewModel;
    @Inject
    public AuthViewModelFactory authViewModelFactory;
    private AuthViewModel authViewModel;

    //track click states:
    private final ArrayList<UiStates> uiStates = new ArrayList<>();

    enum UiStates {
        LOGIN_IN_PROGRESS,
        CONTINUE_AS_GUEST_IN_PROGRESS
    }

    /***********************************************************************************************
     * *********************************** Lifecycle
     */

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentLoginBinding.inflate(getLayoutInflater());
        binding.setFragment(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        loginViewModel = new ViewModelProvider(this).get(LoginViewModel.class);
        authViewModel =
                new ViewModelProvider(requireActivity(), authViewModelFactory).get(AuthViewModel.class);

        // Observe the LiveData for user changes
        if(authViewModel.isLoggedIn()){
            MainNavigationHandler.goToHome(requireActivity());
        }else{
            boolean guestModeInit = authViewModel.getGuestModeBlocking();
            if (guestModeInit) {
                MainNavigationHandler.goToHome(requireActivity());
            }
        }

        super.onViewCreated(view, savedInstanceState);

    }

    /***********************************************************************************************
     * *********************************** Methods
     */

    public void onLoginBtnClick(View view) {
        if (uiStates.contains(UiStates.LOGIN_IN_PROGRESS)) {
            ToastHandler.showToastShort("Login in progress...");
            return;
        }
        uiStates.add(UiStates.LOGIN_IN_PROGRESS);
        binding.loginFragmentLoginBtn.setEnabled(false);

        String email = String.valueOf(binding.loginFragmentEmailTIET.getText());
        String password = String.valueOf(binding.loginFragmentPasswordTIET.getText());

        if (!validate(email, password)) {
            binding.loginFragmentLoginBtn.setEnabled(true);
            uiStates.remove(UiStates.LOGIN_IN_PROGRESS);
            return;
        }

        ProgressDialog progressDialog = new ProgressDialog(null);
        progressDialog.show(getChildFragmentManager(),null);
        authViewModel.login(email, password).addOnCompleteListener(task -> {
            progressDialog.dismiss();
            if (!task.isSuccessful()) {
                binding.loginFragmentLoginBtn.setEnabled(true);
                uiStates.remove(UiStates.LOGIN_IN_PROGRESS);
                ToastHandler.showToastLong("Login Failed..");
            } else {
                authViewModel.setGuestMode(false);
                MainNavigationHandler.goToHome(requireActivity());
            }
        });
    }

    public void onContinueAsGuestClick(View view) {
        if (uiStates.contains(UiStates.CONTINUE_AS_GUEST_IN_PROGRESS)) {
            ToastHandler.showToastShort("Please wait...");
            return;
        }
        uiStates.add(UiStates.CONTINUE_AS_GUEST_IN_PROGRESS);
        binding.loginFragmentContinueAsGuestMTV.setEnabled(false);

        ProgressDialog progressDialog = new ProgressDialog(null);
        progressDialog.show(getChildFragmentManager(),null);
        authViewModel.setGuestMode(true).thenAccept(result -> Worker.runOnUiThread(() -> {
            progressDialog.dismiss();
            uiStates.remove(UiStates.CONTINUE_AS_GUEST_IN_PROGRESS);
            if (result) {
                MainNavigationHandler.goToHome(requireActivity());
            } else {
                ToastHandler.showToastLong("Error..");
                binding.loginFragmentContinueAsGuestMTV.setEnabled(true);
            }
        }));

    }


    /***********************************************************************************************
     * *********************************** Validation
     */

    private boolean validate(String email, String password) {
        if (!ValidationUtils.isEmailValid(email)) {
            binding.loginFragmentEmailTIL.setErrorEnabled(true);
            binding.loginFragmentEmailTIL.setError("Email is invalid!");
            return false;
        } else {
            binding.loginFragmentEmailTIL.setErrorEnabled(false);
            binding.loginFragmentEmailTIL.setError(null);
        }
        if (!ValidationUtils.isPasswordValid(password)) {
            binding.loginFragmentPasswordTIL.setErrorEnabled(true);
            binding.loginFragmentPasswordTIL.setError("Password is invalid!");
            return false;
        } else {
            binding.loginFragmentPasswordTIL.setErrorEnabled(false);
            binding.loginFragmentPasswordTIL.setError(null);
        }
        return true;
    }
}
