package com.abdou.boucetta.plateapp.domain.viewmodels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.abdou.boucetta.plateapp.data.local.models.entities.PlateDetectionResult;
import com.abdou.boucetta.plateapp.data.local.pref.SharedPreferencesHelper;
import com.abdou.boucetta.plateapp.data.local.repository.RoomRepository;
import com.abdou.boucetta.plateapp.data.remote.firestore.FirebaseFirestoreHelper;
import com.abdou.boucetta.plateapp.domain.utils.background.Worker;

import java.util.List;
import java.util.concurrent.Callable;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class HomeViewModel extends ViewModel {
    private static final String TAG = "LoginViewModel";

    /***********************************************************************************************
     * *********************************** Declarations
     */

    private final SharedPreferencesHelper sharedPreferencesHelper;
    private final FirebaseFirestoreHelper firebaseFirestoreHelper;
    private final RoomRepository roomRepository;

    /***********************************************************************************************
     * *********************************** Constructor
     */
    @Inject
    public HomeViewModel(
            SharedPreferencesHelper sharedPreferencesHelper,
            FirebaseFirestoreHelper firebaseFirestoreHelper,
            RoomRepository roomRepository
    ) {
        this.sharedPreferencesHelper = sharedPreferencesHelper;
        this.firebaseFirestoreHelper = firebaseFirestoreHelper;
        this.roomRepository = roomRepository;

    }


    /***********************************************************************************************
     * *********************************** Methods
     */


    /***********************************************************************************************
     * *********************************** Data
     */

    public void getPlateByReference(String reference,
                                    FirebaseFirestoreHelper.PlateInfoResponseListener plateInfoResponseListener){
        firebaseFirestoreHelper.getPlateInfoByReference(reference,plateInfoResponseListener);
    }

    public void addDetectionResult(PlateDetectionResult plateDetectionResult){
        Worker.executeInBackground((Callable<PlateDetectionResult>) () -> {
            roomRepository.insertPlateDetectionResult(plateDetectionResult);
            return null;
        });
    }

    public LiveData<List<PlateDetectionResult>> getAllPlateDetectionResults(){
       return roomRepository.getAllPlateDetectionResults();
    }

    public void deletePlateDetectionResults(List<PlateDetectionResult> plateDetectionResults) {
        Worker.executeInBackground((Callable<PlateDetectionResult>) () -> {
            roomRepository.deletePlateDetectionResultList(plateDetectionResults);
            return null;
        });
    }
}
