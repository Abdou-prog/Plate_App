package com.abdou.boucetta.plateapp.ui.views.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.abdou.boucetta.plateapp.data.local.models.entities.PlateDetectionResult;
import com.abdou.boucetta.plateapp.databinding.ListItemHomePlateBinding;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;


public class DetectionResultAdapter extends RecyclerView.Adapter<DetectionResultAdapter.DetectionResultViewHolder> {
    private static final String TAG = "DetectionResultAdapter";
    private List<PlateDetectionResult> dataList;
    private List<PlateDetectionResult> dataListToRemove = new ArrayList<>();
    private final DetectionResultListener detectionResultListener;
    private boolean selectionMode = false;

    public DetectionResultAdapter(List<PlateDetectionResult> dataList,
                                  DetectionResultListener detectionResultListener) {
        this.dataList = dataList;
        this.detectionResultListener = new DetectionResultListener() {
            @Override
            public void onItemClick(PlateDetectionResult plateDetectionResult) {
                if (selectionMode) {
                    if (dataListToRemove.contains(plateDetectionResult)) {
                        dataListToRemove.remove(plateDetectionResult);
                        detectionResultListener.onAllSelected(false);
                    } else {
                        if (dataListToRemove.size() == (DetectionResultAdapter.this.dataList.size() - 1)) {
                            toggleSelectAll();
                        } else {
                            dataListToRemove.add(plateDetectionResult);
                            detectionResultListener.onAllSelected(false);
                        }
                    }
                    notifyDataSetChanged();
                } else {
                    detectionResultListener.onItemClick(plateDetectionResult);
                }
            }

            @Override
            public void onItemLongClick(PlateDetectionResult plateDetectionResult) {
                if (!selectionMode) {
                    selectionMode = true;
                    dataListToRemove.add(plateDetectionResult);
                    notifyDataSetChanged();
                    detectionResultListener.onItemLongClick(plateDetectionResult);
                }
            }

            @Override
            public void onAllSelected(boolean isAllSelected) {
                detectionResultListener.onAllSelected(isAllSelected);
            }

            @Override
            public void onDeleteSelectedEvent(List<PlateDetectionResult> plateDetectionResults) {
                ArrayList<PlateDetectionResult> clonedList = new ArrayList<>(plateDetectionResults);
                if (selectionMode) {
                    dataListToRemove.clear();
                    notifyDataSetChanged();
                    selectionMode = false;
                }
                detectionResultListener.onDeleteSelectedEvent(clonedList);
            }

            @Override
            public void onResetSelection() {
                if (selectionMode) {
                    dataListToRemove.clear();
                    notifyDataSetChanged();
                    selectionMode = false;
                }
                detectionResultListener.onResetSelection();
            }
        };
    }

    @NonNull
    @Override
    public DetectionResultViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ListItemHomePlateBinding binding =
                ListItemHomePlateBinding.inflate(LayoutInflater.from(parent.getContext()), parent
                        , false);
        return new DetectionResultViewHolder(binding, detectionResultListener);
    }

    @Override
    public void onBindViewHolder(@NonNull DetectionResultViewHolder holder, int position) {
        PlateDetectionResult currentItem = dataList.get(position);

        holder.init(currentItem, selectionMode, dataListToRemove.contains(currentItem));

    }

    @Override
    public int getItemCount() {
        if (dataList != null) {
            return dataList.size();
        }
        return 0;
    }

    public void updateData(List<PlateDetectionResult> newDataList) {
        dataList = newDataList;
        notifyDataSetChanged();
    }

    public void toggleSelectAll() {
        if (selectionMode) {
            if (new HashSet<>(dataListToRemove).containsAll(dataList)) {
                dataListToRemove.clear();
                detectionResultListener.onAllSelected(false);
            } else {
                dataListToRemove.clear();
                dataListToRemove.addAll(dataList);
                detectionResultListener.onAllSelected(true);
            }
            notifyDataSetChanged();
        }
    }

    public void deleteSelected() {
        detectionResultListener.onDeleteSelectedEvent(dataListToRemove);
    }

    public void resetSelection() {
        detectionResultListener.onResetSelection();
    }

    public static class DetectionResultViewHolder extends RecyclerView.ViewHolder {
        public ListItemHomePlateBinding binding;
        public DetectionResultListener detectionResultListener;

        public DetectionResultViewHolder(ListItemHomePlateBinding binding,
                                         DetectionResultListener detectionResultListener) {
            super(binding.getRoot());
            this.binding = binding;
            this.detectionResultListener = detectionResultListener;
        }

        public void init(PlateDetectionResult currentItem, boolean selectionMode,
                         boolean isSelected) {
            binding.listItemHomePlateReferenceMTV.setText(currentItem.getReference());
            binding.listItemHomePlateTypeMTV.setText(currentItem.getType());
            binding.getRoot().setOnClickListener(view -> detectionResultListener.onItemClick(currentItem));
            binding.getRoot().setOnLongClickListener(view -> {
                detectionResultListener.onItemLongClick(currentItem);
                return true;
            });
            if (selectionMode) {
                binding.listItemHomePlateSelectedCB.setVisibility(View.VISIBLE);
                binding.listItemHomePlateSelectedCB.setChecked(isSelected);
            } else {
                binding.listItemHomePlateSelectedCB.setVisibility(View.GONE);
            }
        }
    }

    public interface DetectionResultListener {
        void onItemClick(PlateDetectionResult plateDetectionResult);

        void onItemLongClick(PlateDetectionResult plateDetectionResult);

        void onAllSelected(boolean isAllSelected);

        void onDeleteSelectedEvent(List<PlateDetectionResult> plateDetectionResults);

        void onResetSelection();
    }

}
