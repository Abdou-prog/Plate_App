package com.abdou.boucetta.plateapp.domain.utils.background;


import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;

public class CustomCompletableFuture<T> {
    public static final String TAG = "CustomCompletableFuture";

    private final Executor executor;
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicReference<T> result = new AtomicReference<>();
    private final AtomicReference<Throwable> exception = new AtomicReference<>();
    private final AtomicReference<CustomConsumer<? super T>> action = new AtomicReference<>();

    public CustomCompletableFuture(Executor executor) {
        this.executor = executor;
    }

    public static <U> CustomCompletableFuture<U> supplyAsync(Callable<U> callable, Executor executor) {
        CustomCompletableFuture<U> future = new CustomCompletableFuture<>(executor);
        future.executor.execute(() -> {
            try {
                U result = callable.call();
                future.complete(result);
            } catch (Exception e) {
                future.completeExceptionally(e);
            }
        });
        return future;
    }
    public static <U> CustomCompletableFuture<U> supplySync(Callable<U> callable) {
        CustomCompletableFuture<U> future = new CustomCompletableFuture<>(null);
        if (future.isMainThread()){
            try {
                U result = callable.call();
                future.complete(result);
            } catch (Exception e) {
                future.completeExceptionally(e);
            }
        }else{
            mainHandler.post(() -> {
                try {
                    U result = callable.call();
                    future.complete(result);
                } catch (Exception e) {
                    future.completeExceptionally(e);
                }
            });
        }
        return future;
    }

    public void thenAccept(CustomConsumer<? super T> consumer) {
        action.set(consumer);
        if (result.get() != null) {
            runAction();
        }
    }

    private void complete(T value) {
        result.set(value);
        runAction();
    }

    private void completeExceptionally(Throwable throwable) {
        exception.set(throwable);
        runAction();
    }

    private void runAction() {
        if (action.get() != null) {
            if (exception.get() != null) {
                Log.e(TAG, "runAction: ", exception.get());
                action.get().accept(null);
            } else {
                action.get().accept(result.get());
            }
        }
    }

    private boolean isMainThread() {
        return Looper.myLooper() == Looper.getMainLooper();
    }
}