package com.abdou.boucetta.plateapp.domain.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import com.abdou.boucetta.plateapp.data.local.pref.SharedPreferencesHelper;
import com.abdou.boucetta.plateapp.domain.utils.background.CustomCompletableFuture;
import com.abdou.boucetta.plateapp.domain.utils.background.Worker;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import javax.inject.Inject;

import dagger.hilt.android.qualifiers.ApplicationContext;

public class AuthViewModel extends AndroidViewModel {
    private static final String TAG = "LoginViewModel";

    /***********************************************************************************************
     * *********************************** Declarations
     */
    private final SharedPreferencesHelper sharedPreferencesHelper;
    private final FirebaseAuth firebaseAuth;
    private final MutableLiveData<Boolean> isLoggedIn;
    private final MutableLiveData<FirebaseUser> currentUserLiveData;
    private final FirebaseAuth.AuthStateListener mAuthListener;

    /***********************************************************************************************
     * *********************************** Constructor
     */
    @Inject
    public AuthViewModel(
            @ApplicationContext Application application,
            FirebaseAuth auth,
            SharedPreferencesHelper sharedPreferencesHelper
    ) {
        super(application);
        this.firebaseAuth = auth;
        this.sharedPreferencesHelper = sharedPreferencesHelper;

        isLoggedIn = new MutableLiveData<>(false);
        currentUserLiveData = new MutableLiveData<FirebaseUser>() {
            @Override
            protected void onActive() {
                // Add the AuthStateListener when the LiveData becomes active
                firebaseAuth.addAuthStateListener(mAuthListener);
            }

            @Override
            protected void onInactive() {
                // Remove the AuthStateListener when the LiveData becomes inactive
                firebaseAuth.removeAuthStateListener(mAuthListener);
            }
        };
        mAuthListener = firebaseAuth -> {
            if (firebaseAuth.getCurrentUser() != null){
                isLoggedIn.postValue(true);
            }else{
                isLoggedIn.postValue(false);
            }
            currentUserLiveData.postValue(firebaseAuth.getCurrentUser());
        };
    }


    /***********************************************************************************************
     * *********************************** Methods
     */

    public Task<AuthResult> login(String email, String password){
        return firebaseAuth.signInWithEmailAndPassword(email, password);
    }

    public void logout(){
        firebaseAuth.signOut();
    }

    /***********************************************************************************************
     * *********************************** Data
     */

    public MutableLiveData<FirebaseUser> getCurrentUserLiveData() {
        return currentUserLiveData;
    }

    public boolean isLoggedIn() {
        return firebaseAuth.getCurrentUser() != null;
    }

    public CustomCompletableFuture<Boolean> getGuestMode(){
        return Worker.executeInBackground(sharedPreferencesHelper::getGuestMode);
    }
    public CustomCompletableFuture<Boolean> setGuestMode(boolean guestMode){
        return Worker.executeInBackground(() -> {
            sharedPreferencesHelper.setGuestMode(guestMode);
            return guestMode;
        });
    }
    public void setGuestModeBlocking(boolean guestMode){
        sharedPreferencesHelper.setGuestMode(guestMode);
    }
    public boolean getGuestModeBlocking() {
        return sharedPreferencesHelper.getGuestMode();
    }
}
