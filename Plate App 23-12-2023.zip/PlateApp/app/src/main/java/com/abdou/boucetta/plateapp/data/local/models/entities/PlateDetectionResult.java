package com.abdou.boucetta.plateapp.data.local.models.entities;

import android.net.Uri;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import lombok.Data;

@Data
@Entity
public class PlateDetectionResult {
    public static String TYPE_SAFE = "Safe";
    public static String TYPE_DANGEROUS = "Dangerous";

    @PrimaryKey(autoGenerate = true)
    private Long id;
    private String reference;
    private String type;
    private Uri imageUri;

}
