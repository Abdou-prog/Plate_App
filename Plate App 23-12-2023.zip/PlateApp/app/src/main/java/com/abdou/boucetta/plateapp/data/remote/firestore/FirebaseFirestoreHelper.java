package com.abdou.boucetta.plateapp.data.remote.firestore;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.abdou.boucetta.plateapp.data.remote.dto.PlateInfo;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.List;

public class FirebaseFirestoreHelper {
    private static final String TAG = "FirebaseFirestoreHelper";

    /***********************************************************************************************
     * *********************************** Declarations
     */
    private static final String PLATE_INFO_COLLECTION = "plateInfo";
    private final FirebaseFirestore firebaseFirestore;
    private final CollectionReference plateInfoCollection;

    /***********************************************************************************************
     * *********************************** Constructor
     */
    public FirebaseFirestoreHelper(FirebaseFirestore firebaseFirestore) {
        this.firebaseFirestore = firebaseFirestore;
        this.plateInfoCollection = firebaseFirestore.collection(PLATE_INFO_COLLECTION);
    }

    public void getPlateInfoByReference(String reference,
                                        @NonNull PlateInfoResponseListener plateInfoResponseListener) {
        plateInfoCollection.whereEqualTo("reference", reference)
                .limit(1)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()){
                        plateInfoResponseListener.onSuccess(null);
                    }else{
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            PlateInfo plateInfo = document.toObject(PlateInfo.class);
                            plateInfoResponseListener.onSuccess(plateInfo);
                        }
                    }
                })
                .addOnFailureListener(plateInfoResponseListener::onFailure);
    }

    public void uploadPlateInfoList(List<PlateInfo> plateInfoList,
                                    @NonNull PlateInfoListUploadListener plateInfoListUploadListener) {

        WriteBatch batch = firebaseFirestore.batch();

        for (PlateInfo plateInfo : plateInfoList) {
            DocumentReference documentReference = plateInfoCollection.document();
            batch.set(documentReference, plateInfo);
        }

        batch.commit()
                .addOnSuccessListener(aVoid -> {
                    plateInfoListUploadListener.onSuccess();
                })
                .addOnFailureListener(plateInfoListUploadListener::onFailure);
    }

    public FirestoreRecyclerOptions<PlateInfo> getAllPlateInfosQueryOptions() {
        Query query = plateInfoCollection.orderBy("lastModifiedDate", Query.Direction.DESCENDING);
        return new FirestoreRecyclerOptions.Builder<PlateInfo>()
                .setQuery(query, PlateInfo.class)
                .build();
    }

    public void addPlateInfo(PlateInfo plateInfo) {
        plateInfoCollection.add(plateInfo);
    }

    public void editPlateInfo(PlateInfo plateInfo) {
        plateInfoCollection.document(plateInfo.getId()).set(plateInfo);
    }

    public void deletePlateInfo(String plateInfoId) {
        plateInfoCollection.document(plateInfoId).delete();
    }

    public interface PlateInfoResponseListener {
        void onSuccess(@Nullable PlateInfo plateInfo);

        void onFailure(Exception e);
    }

    public interface PlateInfoListUploadListener {
        void onSuccess();

        void onFailure(Exception e);
    }

}
