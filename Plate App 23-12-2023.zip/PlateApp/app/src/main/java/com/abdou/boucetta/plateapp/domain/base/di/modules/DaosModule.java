package com.abdou.boucetta.plateapp.domain.base.di.modules;

import com.abdou.boucetta.plateapp.data.local.dao.PlateDetectionResultDao;
import com.abdou.boucetta.plateapp.data.local.database.AppDatabase;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.components.SingletonComponent;

@Module
@InstallIn(SingletonComponent.class)
public class DaosModule {
    private static final String TAG = "DaosModule";
    @Singleton
    @Provides
    public PlateDetectionResultDao providesPlateDetectionResultDao(AppDatabase appDB) {
        return appDB.plateDetectionResultDao();
    }
}
