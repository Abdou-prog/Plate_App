package com.abdou.boucetta.plateapp.ui.views;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.abdou.boucetta.plateapp.databinding.ActivityMainBinding;
import com.abdou.boucetta.plateapp.domain.base.di.factories.AuthViewModelFactory;
import com.abdou.boucetta.plateapp.domain.viewmodels.AuthViewModel;
import com.abdou.boucetta.plateapp.ui.utils.toast.ToastHandler;
import com.abdou.boucetta.plateapp.ui.views.navigation.MainNavigationHandler;
import com.abdou.boucetta.plateapp.ui.views.utils.photo.CameraRequestManager;
import com.abdou.boucetta.plateapp.ui.views.utils.permissions.PermissionsManager;

import javax.inject.Inject;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MainActivity extends AppCompatActivity implements PermissionsManager.PermissionCallback {
    private ActivityMainBinding binding;
    @Inject
    public AuthViewModelFactory authViewModelFactory;
    private AuthViewModel authViewModel;

    private PermissionsManager permissionsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        CameraRequestManager.init(this);

        authViewModel = new ViewModelProvider(this, authViewModelFactory).get(AuthViewModel.class);
        binding.navHostFragment.post(() -> {
            if (authViewModel.isLoggedIn()){
                MainNavigationHandler.goToHome(MainActivity.this);
            }else {
                boolean guestModeInit = authViewModel.getGuestModeBlocking();
                if (guestModeInit) {
                    MainNavigationHandler.goToHome(MainActivity.this);
                }else{
                    MainNavigationHandler.goToLogin(MainActivity.this);
                }
            }
        });


        permissionsManager = new PermissionsManager(this, this);
        permissionsManager.requestAllPermissions();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        permissionsManager.onRequestPermissionsResult(requestCode, permissions, grantResults);
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public void onPermissionsGranted() {
        if (permissionsManager.isPermissionGranted(Manifest.permission.CAMERA)){
            ToastHandler.showToastLong("CAMERA PERMISSION GRANTED!");
        }
    }

    @Override
    public void onPermissionsDenied() {
        ToastHandler.showToastLong("PERMISSIONS NOT GRANTED");
    }
}