package com.abdou.boucetta.plateapp.ui.views.fragments;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.abdou.boucetta.plateapp.R;
import com.abdou.boucetta.plateapp.data.remote.dto.PlateInfo;
import com.abdou.boucetta.plateapp.databinding.FragmentAdminBinding;
import com.abdou.boucetta.plateapp.databinding.SnackBarDeleteSelectedBinding;
import com.abdou.boucetta.plateapp.domain.base.di.factories.AuthViewModelFactory;
import com.abdou.boucetta.plateapp.domain.viewmodels.AdminViewModel;
import com.abdou.boucetta.plateapp.domain.viewmodels.AuthViewModel;
import com.abdou.boucetta.plateapp.ui.views.adapters.PlateInfoAdapter;
import com.abdou.boucetta.plateapp.ui.views.custom.CustomRecyclerViewStates;
import com.abdou.boucetta.plateapp.ui.views.dialogs.AddEditPlateDialog;
import com.abdou.boucetta.plateapp.ui.views.navigation.MainNavigationHandler;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class AdminFragment extends Fragment {
    private static final String TAG = "AdminFragment";

    /***********************************************************************************************
     * *********************************** Declarations
     */

    private FragmentAdminBinding binding;
    private AdminViewModel adminViewModel;
    @Inject
    public AuthViewModelFactory authViewModelFactory;
    private AuthViewModel authViewModel;
    private Snackbar plateInfoAdapterDeleteModeSnackBar;
    private PlateInfoAdapter plateInfoAdapter;

    /***********************************************************************************************
     * *********************************** Lifecycle
     */

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentAdminBinding.inflate(getLayoutInflater());
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {


        adminViewModel = new ViewModelProvider(this).get(AdminViewModel.class);
        authViewModel =
                new ViewModelProvider(requireActivity(), authViewModelFactory).get(AuthViewModel.class);

        binding.setAuthViewModel(authViewModel);

        binding.setAdminFragmentPlateInfoRVState(CustomRecyclerViewStates.LOADING);

        plateInfoAdapter = new PlateInfoAdapter(adminViewModel.getAllPlateInfosQueryOptions(),
                new PlateInfoAdapter.PlateInfoListener() {
                    @Override
                    public void onItemClick(PlateInfo plateInfo) {
                        AddEditPlateDialog addEditPlateDialog
                                = new AddEditPlateDialog(plateInfo,
                                new AddEditPlateDialog.AddEditPlateDialogListener() {
                                    @Override
                                    public void onSaveBtnClick(PlateInfo plateInfo) {
                                        adminViewModel.editPlateInfo(plateInfo);
                                    }

                                    @Override
                                    public void onCancelBtnClick() {

                                    }
                                });
                        addEditPlateDialog.show(getChildFragmentManager(), null);
                    }

                    @Override
                    public void onItemLongClick(PlateInfo plateInfo) {
                        binding.adminFragmentPlateInfosRVSelectAllLabel.setVisibility(View.VISIBLE);
                        binding.adminFragmentPlateInfosRVSelectAllCB.setVisibility(View.VISIBLE);
                        binding.adminFragmentAddPlateMTV.setVisibility(View.GONE);
                        binding.adminFragmentAddPlateBtn.setVisibility(View.GONE);
                        binding.adminFragmentPlateInfosRVSelectAllCB.setOnClickListener(view12 ->
                                plateInfoAdapter.toggleSelectAll());
                        plateInfoAdapterDeleteModeSnackBarShow(binding.getRoot());
                    }

                    @Override
                    public void onAllSelected(boolean isAllSelected) {
                        binding.adminFragmentPlateInfosRVSelectAllCB
                                .setChecked(isAllSelected);
                    }

                    @Override
                    public void onDeleteSelectedEvent(List<PlateInfo> plateInfos) {
                        adminViewModel.deletePlateInfos(plateInfos);
                        plateInfoAdapter.resetSelection();
                    }

                    @Override
                    public void onResetSelection() {
                        binding.adminFragmentPlateInfosRVSelectAllCB
                                .setChecked(false);
                        binding.adminFragmentPlateInfosRVSelectAllLabel.setVisibility(View.GONE);
                        binding.adminFragmentPlateInfosRVSelectAllCB.setVisibility(View.GONE);
                        binding.adminFragmentAddPlateMTV.setVisibility(View.VISIBLE);
                        binding.adminFragmentAddPlateBtn.setVisibility(View.VISIBLE);
                        plateInfoAdapterDeleteModeSnackBarHide();
                    }
                });

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext(),
                LinearLayoutManager.VERTICAL, false);

        binding.adminFragmentPlateInfoRV.setLayoutManager(linearLayoutManager);

        binding.adminFragmentPlateInfoRV.setAdapter(plateInfoAdapter);

        binding.setAdminFragmentPlateInfoRVState(CustomRecyclerViewStates.SHOW_DATA);

        binding.adminFragmentAddPlateBtn.setOnClickListener(view1 -> {
            AddEditPlateDialog addEditPlateDialog
                    = new AddEditPlateDialog(null,
                    new AddEditPlateDialog.AddEditPlateDialogListener() {
                        @Override
                        public void onSaveBtnClick(PlateInfo plateInfo) {
                            adminViewModel.addPlateInfo(plateInfo);
                        }

                        @Override
                        public void onCancelBtnClick() {

                        }
                    });
            addEditPlateDialog.show(getChildFragmentManager(), null);
        });

        binding.adminFragmentBackBtn.setOnClickListener(view12 -> MainNavigationHandler.goToHome(requireActivity()));


        binding.adminFragmentMenuToggle.setOnClickListener(this::showPopupMenu);


        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void onStart() {
        super.onStart();
        plateInfoAdapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        plateInfoAdapter.stopListening();
    }

    /***********************************************************************************************
     * *********************************** Methods
     */

    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(requireContext(), view);
        popupMenu.inflate(R.menu.main_menu);

        // Initially hide menuItem2
        MenuItem mainMenuAdminItem = popupMenu.getMenu().findItem(R.id.mainMenuAdminItem);
        MenuItem mainMenuHomeItem = popupMenu.getMenu().findItem(R.id.mainMenuHomeItem);
        MenuItem mainMenuLoginItem = popupMenu.getMenu().findItem(R.id.mainMenuLoginItem);
        MenuItem mainMenuLogoutItem = popupMenu.getMenu().findItem(R.id.mainMenuLogoutItem);

        if (authViewModel.isLoggedIn()) {
            mainMenuAdminItem.setVisible(false);
            mainMenuHomeItem.setVisible(true);
            mainMenuLoginItem.setVisible(false);
            mainMenuLogoutItem.setVisible(true);
        } else {
            mainMenuAdminItem.setVisible(false);
            mainMenuHomeItem.setVisible(true);
            mainMenuLoginItem.setVisible(true);
            mainMenuLogoutItem.setVisible(false);
        }

        popupMenu.setOnMenuItemClickListener((MenuItem menuItem) -> {
            if (menuItem.getItemId() == R.id.mainMenuHomeItem) {
                MainNavigationHandler.goToHome(requireActivity());
                return true;
            }
            if (menuItem.getItemId() == R.id.mainMenuLoginItem) {
                authViewModel.setGuestMode(false);
                MainNavigationHandler.goToLogin(requireActivity());
                return true;
            }
            if (menuItem.getItemId() == R.id.mainMenuLogoutItem) {
                authViewModel.logout();
                authViewModel.setGuestMode(false);
                MainNavigationHandler.goToLogin(requireActivity());
                return true;
            }

            return false;
        });

        popupMenu.show();
    }


    /***********************************************************************************************
     * *********************************** Validation
     */


    private void plateInfoAdapterDeleteModeSnackBarShow(View view) {
        if (plateInfoAdapterDeleteModeSnackBar == null) {

            plateInfoAdapterDeleteModeSnackBar = Snackbar.make(view, "",
                    Snackbar.LENGTH_INDEFINITE);

            SnackBarDeleteSelectedBinding snackBarDeleteSelectedBinding =
                    SnackBarDeleteSelectedBinding.inflate(
                            getLayoutInflater(),
                            null,
                            false
                    );

            snackBarDeleteSelectedBinding.snackBarDeleteSelectedCancel.setOnClickListener(v -> {
                plateInfoAdapter.resetSelection();
                plateInfoAdapterDeleteModeSnackBar.dismiss();
            });

            snackBarDeleteSelectedBinding.snackBarDeleteSelectedDelete.setOnClickListener(v -> {
                plateInfoAdapter.deleteSelected();
                plateInfoAdapterDeleteModeSnackBar.dismiss();
            });

            Snackbar.SnackbarLayout snackbarLayout =
                    (Snackbar.SnackbarLayout) plateInfoAdapterDeleteModeSnackBar.getView();
            snackbarLayout.addView(snackBarDeleteSelectedBinding.getRoot(), 0);

            TypedValue typedValue = new TypedValue();
            requireContext().getTheme().resolveAttribute(android.R.attr.colorPrimary, typedValue, true);
            int colorPrimary = typedValue.data;
            plateInfoAdapterDeleteModeSnackBar.setBackgroundTint(colorPrimary);


        }

        plateInfoAdapterDeleteModeSnackBar.show();
    }

    private void plateInfoAdapterDeleteModeSnackBarHide() {
        if (plateInfoAdapterDeleteModeSnackBar != null) {
            plateInfoAdapterDeleteModeSnackBar.dismiss();
        }

    }
}
