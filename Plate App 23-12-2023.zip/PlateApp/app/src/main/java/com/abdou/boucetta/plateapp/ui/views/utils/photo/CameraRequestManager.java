package com.abdou.boucetta.plateapp.ui.views.utils.photo;

import static androidx.activity.result.ActivityResultCallerKt.registerForActivityResult;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import com.abdou.boucetta.plateapp.ui.utils.toast.ToastHandler;

public class CameraRequestManager {
    private static final String TAG = "CameraRequestManager";

    private static ComponentActivity activity;
    private static OnImageCaptureListener onImageCaptureListener;
    private static Uri photoUri;
    private static ActivityResultLauncher<Intent> launcher;


    /**
     * Must be initialized in Activity before state STARTED
     */
    public static void init(ComponentActivity activity) {
        CameraRequestManager.activity = activity;
        launcher = activity.registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> handleImageCaptureResult(result, photoUri)
        );
    }

    /**
     * Set listener wherever it's needed , note that only one listener can be active
     */
    public static void setUpListener(OnImageCaptureListener onImageCaptureListener){
        CameraRequestManager.onImageCaptureListener = onImageCaptureListener;
    }

    /**
     * Launch camera request
     */
    public static void dispatchTakePictureIntent() {
        // Image Uri
        photoUri =
                activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        , new ContentValues());

        // Intent for capturing an image
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);

        // Check if there's a camera app to handle the intent
        if (takePictureIntent.resolveActivity(activity.getPackageManager()) != null) {
            launcher.launch(takePictureIntent);
        } else {
            // Display an error message if no camera app is available
            Toast.makeText(activity, "No camera app available", Toast.LENGTH_SHORT).show();
        }
    }

    private static void handleImageCaptureResult(androidx.activity.result.ActivityResult result,
                                                 Uri photoUri) {
        if (result.getResultCode() == Activity.RESULT_OK) {
            // Image captured and saved to the file specified in the Intent
            // Notify the listener with the captured image URI
            if (onImageCaptureListener != null) {
                onImageCaptureListener.onImageCaptured(photoUri);
            }
        } else {
            Log.d(TAG, "capture photo canceled ");
            ToastHandler.showToastLong("Capture photo canceled");
        }
    }

    public static Uri getPhotoUri() {
        return photoUri;
    }


    public interface OnImageCaptureListener {
        void onImageCaptured(Uri photoUri);
    }
}
