package com.abdou.boucetta.plateapp.domain.base.di.factories;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.abdou.boucetta.plateapp.data.local.pref.SharedPreferencesHelper;
import com.abdou.boucetta.plateapp.domain.viewmodels.AuthViewModel;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;
import java.util.concurrent.ExecutorService;

import javax.inject.Inject;
import javax.inject.Provider;
public class AuthViewModelFactory extends ViewModelProvider.AndroidViewModelFactory {
    private static final String TAG = "ConfigViewModelFactory";

    private final Application application;
    private final FirebaseAuth auth;
    private final SharedPreferencesHelper sharedPreferencesHelper;

    @Inject
    public AuthViewModelFactory(@NonNull Application application,
                                  FirebaseAuth auth,
                                  SharedPreferencesHelper sharedPreferencesHelper) {
        super(application);
        this.sharedPreferencesHelper = sharedPreferencesHelper;
        this.auth = auth;
        this.application = application;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        if (modelClass.isAssignableFrom(AuthViewModel.class)) {
            // Create and return your AndroidViewModel instance here
            return Objects.requireNonNull(modelClass.cast(new AuthViewModel(application, auth,sharedPreferencesHelper)));
        }
        throw new IllegalArgumentException("Unknown ViewModel class: " + modelClass.getName());
    }
}