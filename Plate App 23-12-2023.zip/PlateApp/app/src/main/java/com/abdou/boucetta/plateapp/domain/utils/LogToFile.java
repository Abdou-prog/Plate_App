package com.abdou.boucetta.plateapp.domain.utils;

import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class LogToFile {

    private static final String TAG = "LogToFile";

    public static void redirectLogsToFile() {
        try {
            // Get the Downloads directory path
            File downloadsDirectory = new File(Environment.getExternalStorageDirectory(), Environment.DIRECTORY_DOWNLOADS);

            // Create a log directory within Downloads
            File logDirectory = new File(downloadsDirectory, "plate_app_logs");
            if (!logDirectory.exists()) {
                if (!logDirectory.mkdirs()) {
                    Log.e(TAG, "Failed to create log directory");
                    return;
                }
            }

            // Create a log file with the current date in the filename
            Date currentDate = Calendar.getInstance().getTime();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String formattedDate = dateFormat.format(currentDate);
            File logFile = new File(logDirectory, "plate_app_logcat_" + formattedDate + ".txt");

            // Create a FileOutputStream to write to the file
            FileOutputStream fos = new FileOutputStream(logFile, true);

            // Create a PrintStream to redirect System.out and System.err to the file
            PrintStream ps = new PrintStream(fos);
            System.setOut(ps);
            System.setErr(ps);

            // Redirect logs to the file using LogCat
            redirectLogCatToFile(logFile);

            Log.i(TAG, "Logs redirected to file: " + logFile.getAbsolutePath());
        } catch (IOException e) {
            Log.e(TAG, "Error redirecting logs to file: " + e.getMessage());
        }
    }

    private static void redirectLogCatToFile(File logFile) {
        try {
            // Run logcat command to redirect logs to the file
            Process process = Runtime.getRuntime().exec("logcat -f " + logFile.getAbsolutePath());
            process.waitFor();
        } catch (IOException | InterruptedException e) {
            Log.e(TAG, "Error redirecting logs to file: " + e.getMessage());
        }
    }
}
