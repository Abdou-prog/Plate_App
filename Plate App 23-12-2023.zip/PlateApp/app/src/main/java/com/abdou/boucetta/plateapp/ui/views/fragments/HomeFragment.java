package com.abdou.boucetta.plateapp.ui.views.fragments;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.abdou.boucetta.plateapp.R;
import com.abdou.boucetta.plateapp.data.local.models.entities.PlateDetectionResult;
import com.abdou.boucetta.plateapp.data.remote.dto.PlateInfo;
import com.abdou.boucetta.plateapp.data.remote.firestore.FirebaseFirestoreHelper;
import com.abdou.boucetta.plateapp.databinding.FragmentHomeBinding;
import com.abdou.boucetta.plateapp.databinding.SnackBarDeleteSelectedBinding;
import com.abdou.boucetta.plateapp.domain.base.di.factories.AuthViewModelFactory;
import com.abdou.boucetta.plateapp.domain.viewmodels.AuthViewModel;
import com.abdou.boucetta.plateapp.domain.viewmodels.HomeViewModel;
import com.abdou.boucetta.plateapp.ui.utils.toast.ToastHandler;
import com.abdou.boucetta.plateapp.ui.views.adapters.DetectionResultAdapter;
import com.abdou.boucetta.plateapp.ui.views.custom.CustomRecyclerViewStates;
import com.abdou.boucetta.plateapp.ui.views.dialogs.DetectionFailedDialog;
import com.abdou.boucetta.plateapp.ui.views.dialogs.DetectionResultDialog;
import com.abdou.boucetta.plateapp.ui.views.dialogs.ProgressDialog;
import com.abdou.boucetta.plateapp.ui.views.navigation.MainNavigationHandler;
import com.abdou.boucetta.plateapp.ui.views.utils.photo.CameraRequestManager;
import com.abdou.boucetta.plateapp.ui.views.utils.permissions.PermissionsManager;
import com.abdou.boucetta.plateapp.ui.views.utils.photo.ImagePickerHelper;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HomeFragment extends Fragment implements ImagePickerHelper.OnImagePickedListener {
    private static final String TAG = "HomeFragment";

    /***********************************************************************************************
     * *********************************** Declarations
     */

    private FragmentHomeBinding binding;
    private HomeViewModel homeViewModel;
    @Inject
    public AuthViewModelFactory authViewModelFactory;
    private AuthViewModel authViewModel;
    private PermissionsManager permissionsManager;
    private ImagePickerHelper imagePickerHelper;
    private DetectionResultAdapter detectionResultAdapter;
    private Snackbar detectionResultAdapterDeleteModeSnackBar;

    private final Observer<List<PlateDetectionResult>> allPlateDetectionResultsObserver
            = plateDetectionResults -> {
        if (detectionResultAdapter != null) {
            detectionResultAdapter.updateData(plateDetectionResults);
            if (plateDetectionResults == null || plateDetectionResults.isEmpty()) {
                binding.setHomeFragmentDetectedPlatesRVState(CustomRecyclerViewStates.EMPTY);
            } else {
                binding.setHomeFragmentDetectedPlatesRVState(CustomRecyclerViewStates.SHOW_DATA);
            }
        } else {
            binding.setHomeFragmentDetectedPlatesRVState(CustomRecyclerViewStates.ERROR);
        }
    };

    private TextRecognizer textRecognizer;

    private Uri imageUri;


    /***********************************************************************************************
     * *********************************** Lifecycle
     */

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(getLayoutInflater());
        imagePickerHelper = new ImagePickerHelper(this,this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {


        homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);
        authViewModel =
                new ViewModelProvider(requireActivity(), authViewModelFactory).get(AuthViewModel.class);

        binding.setAuthViewModel(authViewModel);
        CameraRequestManager.setUpListener(photoUri -> {
            if (photoUri != null) {
                imageUri = photoUri;
            }
        });


        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        binding.homeFragmentGalleryBtn.setOnClickListener(this::showInputImageDialog);
        binding.homeFragmentCameraBtn.setOnClickListener(view1 -> recognizeTextFromImage());

        detectionResultAdapter = new DetectionResultAdapter(null,
                new DetectionResultAdapter.DetectionResultListener() {
                    @Override
                    public void onItemClick(PlateDetectionResult plateDetectionResult) {
                        DetectionResultDialog detectionResultDialog
                                = new DetectionResultDialog(plateDetectionResult, null);
                        detectionResultDialog.show(getChildFragmentManager(), null);
                    }

                    @Override
                    public void onItemLongClick(PlateDetectionResult plateDetectionResult) {
                        binding.homeFragmentDetectedPlatesRVSelectAllLabel.setVisibility(View.VISIBLE);
                        binding.homeFragmentDetectedPlatesRVSelectAllCB.setVisibility(View.VISIBLE);
                        binding.homeFragmentDetectedPlatesRVSelectAllCB.setOnClickListener(view12 ->
                                detectionResultAdapter.toggleSelectAll());
                        detectionResultAdapterDeleteModeSnackBarShow(binding.getRoot());
                    }

                    @Override
                    public void onAllSelected(boolean isAllSelected) {
                        binding.homeFragmentDetectedPlatesRVSelectAllCB
                                .setChecked(isAllSelected);
                    }

                    @Override
                    public void onDeleteSelectedEvent(List<PlateDetectionResult> plateDetectionResults) {
                        homeViewModel.deletePlateDetectionResults(plateDetectionResults);
                        detectionResultAdapter.resetSelection();
                    }

                    @Override
                    public void onResetSelection() {
                        binding.homeFragmentDetectedPlatesRVSelectAllCB
                                .setChecked(false);
                        binding.homeFragmentDetectedPlatesRVSelectAllLabel.setVisibility(View.GONE);
                        binding.homeFragmentDetectedPlatesRVSelectAllCB.setVisibility(View.GONE);
                        detectionResultAdapterDeleteModeSnackBarHide();
                    }
                });

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext(),
                LinearLayoutManager.VERTICAL, false);

        binding.setHomeFragmentDetectedPlatesRVState(CustomRecyclerViewStates.LOADING);

        binding.homeFragmentDetectedPlatesRV.setLayoutManager(linearLayoutManager);

        binding.homeFragmentDetectedPlatesRV.setAdapter(detectionResultAdapter);

        homeViewModel.getAllPlateDetectionResults().observe(
                getViewLifecycleOwner(),
                allPlateDetectionResultsObserver
        );


        binding.homeFragmentMenuToggle.setOnClickListener(this::showPopupMenu);

        permissionsManager = new PermissionsManager(requireActivity(), null);

        super.onViewCreated(view, savedInstanceState);

    }

    /***********************************************************************************************
     * *********************************** Methods
     */

    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(requireContext(), view);
        popupMenu.inflate(R.menu.main_menu);

        // Initially hide menuItem2
        MenuItem mainMenuAdminItem = popupMenu.getMenu().findItem(R.id.mainMenuAdminItem);
        MenuItem mainMenuHomeItem = popupMenu.getMenu().findItem(R.id.mainMenuHomeItem);
        MenuItem mainMenuLoginItem = popupMenu.getMenu().findItem(R.id.mainMenuLoginItem);
        MenuItem mainMenuLogoutItem = popupMenu.getMenu().findItem(R.id.mainMenuLogoutItem);

        if (authViewModel.isLoggedIn()) {
            mainMenuAdminItem.setVisible(true);
            mainMenuHomeItem.setVisible(false);
            mainMenuLoginItem.setVisible(false);
            mainMenuLogoutItem.setVisible(true);
        } else {
            mainMenuAdminItem.setVisible(false);
            mainMenuHomeItem.setVisible(false);
            mainMenuLoginItem.setVisible(true);
            mainMenuLogoutItem.setVisible(false);
        }

        popupMenu.setOnMenuItemClickListener((MenuItem menuItem) -> {
            if (menuItem.getItemId() == R.id.mainMenuAdminItem) {
                MainNavigationHandler.goToAdmin(requireActivity());
                return true;
            }
            if (menuItem.getItemId() == R.id.mainMenuLoginItem) {
                authViewModel.setGuestMode(false);
                MainNavigationHandler.goToLogin(requireActivity());
                return true;
            }
            if (menuItem.getItemId() == R.id.mainMenuLogoutItem) {
                authViewModel.logout();
                authViewModel.setGuestMode(false);
                MainNavigationHandler.goToLogin(requireActivity());
                return true;
            }

            return false;
        });

        popupMenu.show();
    }


    private void recognizeTextFromImage() {
        Log.d(TAG, "recognizeTextFromImage:");
        ProgressDialog progressDialog = new ProgressDialog(null);
        progressDialog.show(getChildFragmentManager(), null);
        try {
            InputImage inputImage = InputImage.fromFilePath(requireActivity(), imageUri);
            textRecognizer.process(inputImage)
                    .addOnSuccessListener(text -> {
                        String recognizedText = text.getText();
                        Log.d(TAG, "onSuccess:recognizedText:" + recognizedText);
                        homeViewModel.getPlateByReference(recognizedText,
                                new FirebaseFirestoreHelper.PlateInfoResponseListener() {
                                    @Override
                                    public void onSuccess(PlateInfo plateInfo) {
                                        progressDialog.dismiss();
                                        if (plateInfo != null) {
                                            PlateDetectionResult plateDetectionResult =
                                                    new PlateDetectionResult();
                                            plateDetectionResult.setType(plateInfo.getType());
                                            plateDetectionResult.setReference(plateInfo.getReference());
                                            plateDetectionResult.setImageUri(imageUri);
                                            homeViewModel.addDetectionResult(plateDetectionResult);
                                            DetectionResultDialog detectionResultDialog
                                                    =
                                                    new DetectionResultDialog(plateDetectionResult,
                                                            null);
                                            detectionResultDialog.show(getChildFragmentManager(),
                                                    null);
                                        } else {
                                            DetectionFailedDialog detectionFailedDialog
                                                    = new DetectionFailedDialog(recognizedText, null);
                                            detectionFailedDialog.show(getChildFragmentManager(),
                                                    null);
                                        }
                                    }

                                    @Override
                                    public void onFailure(Exception e) {
                                        FirebaseCrashlytics.getInstance().recordException(e);
                                        progressDialog.dismiss();
                                        Log.e(TAG, "getPlateByReference onFailure: ", e);
                                        DetectionFailedDialog detectionFailedDialog
                                                = new DetectionFailedDialog(recognizedText,null);
                                        detectionFailedDialog.show(getChildFragmentManager(), null);
                                    }
                                });

                    })
                    .addOnFailureListener(e -> {
                        FirebaseCrashlytics.getInstance().recordException(e);
                        progressDialog.dismiss();
                        Log.e(TAG, "onFailure:", e);
                        Toast.makeText(requireActivity(), "Plate Recognition Failed : " + e.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    });

        } catch (Exception e) {
            FirebaseCrashlytics.getInstance().recordException(e);
            progressDialog.dismiss();
            Log.e(TAG, "recognizeTextFromImage:", e);
            Toast.makeText(requireActivity(), "Failed recognizing text due to  " + e.getMessage()
                    , Toast.LENGTH_SHORT).show();
        }
    }

    private void showInputImageDialog(View inputImage) {
        PopupMenu popupMenu = new PopupMenu(requireActivity(), inputImage);
        popupMenu.getMenu().add(Menu.NONE, 1, 1, "CAMERA");
        popupMenu.getMenu().add(Menu.NONE, 2, 2, "GALLERY");
        popupMenu.show();

        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int id = menuItem.getItemId();
            if (id == 1) {
                Log.d(TAG, "onMenuItemClick: Camera Clicked...");
                if (permissionsManager.isCameraPermissionGranted()) {
                    CameraRequestManager.dispatchTakePictureIntent();
                } else {
                    permissionsManager.requestAllPermissions();
                }
            } else if (id == 2) {
                Log.d(TAG, "onMenuItemClick: Gallery Clicked...");
                if (permissionsManager.isStoragePermissionGranted()) {
                    imagePickerHelper.pickImageGallery();
                } else {
                    permissionsManager.requestStoragePermissions();
                }

            }
            return true;
        });

    }

    /***********************************************************************************************
     * *********************************** Validation
     */


    private void detectionResultAdapterDeleteModeSnackBarShow(View view) {
        if (detectionResultAdapterDeleteModeSnackBar == null) {

            detectionResultAdapterDeleteModeSnackBar = Snackbar.make(view, "",
                    Snackbar.LENGTH_INDEFINITE);

            SnackBarDeleteSelectedBinding snackBarDeleteSelectedBinding =
                    SnackBarDeleteSelectedBinding.inflate(
                    getLayoutInflater(),
                    null,
                    false
            );

            snackBarDeleteSelectedBinding.snackBarDeleteSelectedCancel.setOnClickListener(v -> {
                detectionResultAdapter.resetSelection();
                detectionResultAdapterDeleteModeSnackBar.dismiss();
            });

            snackBarDeleteSelectedBinding.snackBarDeleteSelectedDelete.setOnClickListener(v -> {
                detectionResultAdapter.deleteSelected();
                detectionResultAdapterDeleteModeSnackBar.dismiss();
            });

            Snackbar.SnackbarLayout snackbarLayout =
                    (Snackbar.SnackbarLayout) detectionResultAdapterDeleteModeSnackBar.getView();
            snackbarLayout.addView(snackBarDeleteSelectedBinding.getRoot(), 0);


            TypedValue typedValue = new TypedValue();
            requireContext().getTheme().resolveAttribute(android.R.attr.colorPrimary, typedValue, true);
            int colorPrimary = typedValue.data;
            detectionResultAdapterDeleteModeSnackBar.setBackgroundTint(colorPrimary);
        }

        detectionResultAdapterDeleteModeSnackBar.show();
    }

    @Override
    public void onImagePicked(Uri imageUri) {
        if (imageUri != null){
            this.imageUri = imageUri;
        }else{
            ToastHandler.showToastLong("Error Picking Image, invalid URI");
        }
    }

    private void detectionResultAdapterDeleteModeSnackBarHide() {
        if (detectionResultAdapterDeleteModeSnackBar != null) {
            detectionResultAdapterDeleteModeSnackBar.dismiss();
        }

    }
}
