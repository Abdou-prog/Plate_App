package com.abdou.boucetta.plateapp.domain.base;

import android.app.Application;
import android.content.Context;

import com.abdou.boucetta.plateapp.domain.utils.AppUtils;
import com.abdou.boucetta.plateapp.domain.utils.LogToFile;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.firestore.MemoryCacheSettings;
import com.google.firebase.firestore.PersistentCacheSettings;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class BaseApplication extends Application {
    private static final String TAG = "BaseApplication";

    public static Context appContext;
    @Override
    public void onCreate() {
        super.onCreate();
//        AppUtils.initLogSetup();
//        LogToFile.redirectLogsToFile();
        appContext = getApplicationContext();

        FirebaseApp.initializeApp(this);

        FirebaseFirestoreSettings settings =
                new FirebaseFirestoreSettings.Builder(FirebaseFirestore.getInstance().getFirestoreSettings())
//                        // Use memory-only cache
//                        .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
                        // Use persistent disk cache (default)
                        .setLocalCacheSettings(PersistentCacheSettings.newBuilder()
                                .build())
                        .build();
        FirebaseFirestore.getInstance().setFirestoreSettings(settings);

    }
}