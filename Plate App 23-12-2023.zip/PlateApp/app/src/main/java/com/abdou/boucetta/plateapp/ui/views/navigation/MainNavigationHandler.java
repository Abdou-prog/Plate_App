package com.abdou.boucetta.plateapp.ui.views.navigation;


import android.app.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;

import com.abdou.boucetta.plateapp.R;
import com.abdou.boucetta.plateapp.ui.views.fragments.AdminFragmentDirections;
import com.abdou.boucetta.plateapp.ui.views.fragments.HomeFragmentDirections;
import com.abdou.boucetta.plateapp.ui.views.fragments.LoginFragmentDirections;

import java.util.Objects;

public class MainNavigationHandler {
    private static final String TAG = "MainNavigationHandler";

    public static void startWithLogin(AppCompatActivity activity) {
        activity.runOnUiThread(() -> {
            NavHostFragment navHostFragment = (NavHostFragment)
                    activity.getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
            NavController navController =
                    Objects.requireNonNull(navHostFragment).getNavController();
            navController.getGraph().setStartDestination(R.id.login_fragment);
        });
    }

    public static void startWithHome(AppCompatActivity activity) {
        activity.runOnUiThread(() -> {
            NavHostFragment navHostFragment = (NavHostFragment)
                    activity.getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
            NavController navController =
                    Objects.requireNonNull(navHostFragment).getNavController();
            navController.getGraph().setStartDestination(R.id.home_fragment);
        });
    }

    public static void goToLogin(Activity activity) {
        activity.runOnUiThread(() -> {
            NavController navController = Navigation.findNavController(activity,
                    R.id.nav_host_fragment);
            NavDestination currentDestination = navController.getCurrentDestination();
            if (currentDestination == null) {
                return;
            }
            if (currentDestination.getId() == R.id.login_fragment) {
                return;
            }
            if (currentDestination.getId() == R.id.admin_fragment) {
                adminToLogin(activity);
            }
            if (currentDestination.getId() == R.id.home_fragment) {
                homeToLogin(activity);
            }
        });
    }

    public static void goToAdmin(Activity activity) {
        activity.runOnUiThread(() -> {
            NavController navController = Navigation.findNavController(activity,
                    R.id.nav_host_fragment);
            NavDestination currentDestination = navController.getCurrentDestination();
            if (currentDestination == null) {
                return;
            }
            if (currentDestination.getId() == R.id.login_fragment) {
                loginToAdmin(activity);
            }
            if (currentDestination.getId() == R.id.admin_fragment) {
                return;
            }
            if (currentDestination.getId() == R.id.home_fragment) {
                homeToAdmin(activity);
            }
        });
    }

    public static void goToHome(Activity activity) {
        activity.runOnUiThread(() -> {
            NavController navController = Navigation.findNavController(activity,
                    R.id.nav_host_fragment);
            NavDestination currentDestination = navController.getCurrentDestination();
            if (currentDestination == null) {
                return;
            }
            if (currentDestination.getId() == R.id.login_fragment) {
                loginToHome(activity);
            }
            if (currentDestination.getId() == R.id.admin_fragment) {
                adminToHome(activity);
            }
        });
    }

    private static void loginToAdmin(Activity activity) {
        activity.runOnUiThread(() -> {
            NavDirections action = LoginFragmentDirections.loginToAdmin();
            Navigation.findNavController(activity, R.id.nav_host_fragment)
                    .navigate(action);
        });
    }

    private static void loginToHome(Activity activity) {
        activity.runOnUiThread(() -> {
            NavDirections action = LoginFragmentDirections.loginToHome();
            Navigation.findNavController(activity, R.id.nav_host_fragment)
                    .navigate(action);
        });
    }

    private static void adminToLogin(Activity activity) {
        activity.runOnUiThread(() -> {
            NavDirections action = AdminFragmentDirections.adminToLogin();
            Navigation.findNavController(activity, R.id.nav_host_fragment)
                    .navigate(action);
        });
    }

    private static void adminToHome(Activity activity) {
        activity.runOnUiThread(() -> {
            NavDirections action = AdminFragmentDirections.adminToHome();
            Navigation.findNavController(activity, R.id.nav_host_fragment)
                    .navigate(action);
        });
    }

    private static void homeToAdmin(Activity activity) {
        activity.runOnUiThread(() -> {
            NavDirections action = HomeFragmentDirections.homeToAdmin();
            Navigation.findNavController(activity, R.id.nav_host_fragment)
                    .navigate(action);
        });
    }

    private static void homeToLogin(Activity activity) {
        activity.runOnUiThread(() -> {
            NavDirections action = HomeFragmentDirections.homeToLogin();
            Navigation.findNavController(activity, R.id.nav_host_fragment)
                    .navigate(action);
        });
    }

}
