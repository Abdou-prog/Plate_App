package com.abdou.boucetta.plateapp.data.local.pref;


import android.content.SharedPreferences;

import lombok.Getter;

public class SharedPreferencesHelper {
    private static final String TAG = "SharedPreferencesHelper";

    /***********************************************************************************************
     * *********************************** Declarations
     */
    private final SharedPreferences sharedPreferences;
    private final SharedPreferences.Editor editor;
    private static final String GUEST_MODE = "GUEST_MODE";

    /***********************************************************************************************
     * *********************************** Constructor
     */
    public SharedPreferencesHelper(SharedPreferences sharedPreferences) {
        this.sharedPreferences = sharedPreferences;
        editor = sharedPreferences.edit();
    }

    public void setGuestMode(boolean guestMode) {
        editor.putBoolean(GUEST_MODE,guestMode).apply();
    }
    public boolean getGuestMode() {
        return sharedPreferences.getBoolean(GUEST_MODE,false);
    }

}
