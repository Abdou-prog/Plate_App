package com.abdou.boucetta.plateapp.ui.views.dialogs;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.abdou.boucetta.plateapp.R;
import com.abdou.boucetta.plateapp.data.remote.dto.PlateInfo;
import com.abdou.boucetta.plateapp.databinding.DialogAddEditPlateBinding;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.Date;

public class AddEditPlateDialog extends AppCompatDialogFragment {
    public static final String TAG = "AddEditPlateDialog";
    private final AddEditPlateDialogListener addEditPlateDialogListener;
    private PlateInfo plateInfo;

    public AddEditPlateDialog(@Nullable PlateInfo plateInfo,
                              @Nullable AddEditPlateDialogListener addEditPlateDialogListener) {
        this.plateInfo = plateInfo;
        this.addEditPlateDialogListener = addEditPlateDialogListener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireActivity());

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        DialogAddEditPlateBinding binding =
                DialogAddEditPlateBinding.inflate(inflater);

        builder.setView(binding.getRoot());

        binding.dialogAddEditPlateSaveBtn.setOnClickListener(view -> {
            if (addEditPlateDialogListener != null) {
                if (plateInfo == null) {
                    plateInfo = new PlateInfo();
                }
                plateInfo.setReference(String.valueOf(binding.dialogAddEditPlateReferenceTIET.getText()));
                plateInfo.setType(String.valueOf(binding.dialogAddEditPlateTypeACTV.getText()));
                plateInfo.setLastModifiedDate(new Date());
                addEditPlateDialogListener.onSaveBtnClick(plateInfo);
            }
            dismiss();
        });
        binding.dialogAddEditPlateCancelBtn.setOnClickListener(view -> {
            if (addEditPlateDialogListener != null) {
                addEditPlateDialogListener.onCancelBtnClick();
            }
            dismiss();
        });

        ArrayAdapter<String> plateTypeDropdownAdapter = new ArrayAdapter<>(requireContext(),
                R.layout.dropdown_item_plate_type);
        plateTypeDropdownAdapter.add(PlateInfo.TYPE_SAFE);
        plateTypeDropdownAdapter.add(PlateInfo.TYPE_DANGEROUS);
        binding.dialogAddEditPlateTypeACTV.setAdapter(plateTypeDropdownAdapter);

        if (plateInfo != null) {
            binding.dialogAddEditPlateReferenceTIET.setText(plateInfo.getReference());
            binding.dialogAddEditPlateTypeACTV.setText(plateInfo.getType(), false);
        }


        return builder.create();
    }

    public interface AddEditPlateDialogListener {
        void onSaveBtnClick(PlateInfo plateInfo);

        void onCancelBtnClick();
    }
}
