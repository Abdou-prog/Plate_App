package com.abdou.boucetta.plateapp.ui.views.dialogs;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.abdou.boucetta.plateapp.databinding.DialogProgressBinding;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class ProgressDialog  extends AppCompatDialogFragment {
    public static final String TAG = "ProgressDialog";
    private final String description;

    public ProgressDialog(@Nullable String description) {
        this.description = description;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireActivity());

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        DialogProgressBinding binding =
                DialogProgressBinding.inflate(inflater);

        builder.setView(binding.getRoot());
        builder.setCancelable(false);

        if (description != null){
            binding.dialogProgressDescription.setText(description);
        }
        AlertDialog alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        return alertDialog;
    }

}
