package com.abdou.boucetta.plateapp.ui.views.utils;

import android.util.Patterns;

public class ValidationUtils {
    private static final String TAG = "ValidationUtils";

    public static boolean isEmailValid(String email) {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    public static boolean isPasswordValid(String password) {
        // You can add more password validation rules if needed
        return password != null && password.length() >= 6;
    }
}