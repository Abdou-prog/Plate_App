package com.abdou.boucetta.plateapp.domain.utils.exceptions;

public class UserNotLoggedInException extends Exception {
    private static final String MESSAGE = "User not logged in exception";

    public UserNotLoggedInException(String message) {
        super(message);
    }
    public UserNotLoggedInException() {
        super(MESSAGE);
    }
}
